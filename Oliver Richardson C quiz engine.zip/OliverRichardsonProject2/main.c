#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Oliver Richardson R00175244 Project 2
struct q_a{
    char question[100];
    char answer[50];
}quiz[100];





int read_file(const char *path) {
    FILE *fp;
    char c;
    int count = 0;
    fp = fopen(path, "r");
    if (fp == NULL)
    {
        printf("Could not open file/Invalid file path\n");
        return 0;
    }
    for (c = getc(fp); c != EOF; c = getc(fp)) {
        if (c == '\n') {
            count++;
        }
    }

    printf("There are %d questions\n",count);
    fclose(fp);

// I tried to do dynamic but I ran into issues using malloc

   //struct q_a *quiz;
    //quiz = malloc(count * sizeof(struct q_a));

//    int qnum_characters = 0;
//    int anum_characters;
//    int temp = 0;
//    int index = 0;


//    fp = fopen(path, "r");
//    char end = '?';
//
//    for (c = getc(fp); c != EOF; c = getc(fp)) {
//        qnum_characters++;
//        printf("%c", c);
//        if (c == end) {
//            printf("%d", qnum_characters);
//            quiz[index].question = (char*) malloc(qnum_characters);
//            temp = qnum_characters;
//        }
//        if (c == '\n'){
//            anum_characters = qnum_characters - temp;
//            quiz[index].answer = (char*) malloc(anum_characters);
//            index++;
//            qnum_characters = 0;
//            printf("%d", anum_characters);
//
//        }
//
//    }
//
//    fclose(fp);

    fp = fopen(path, "r");
    int i = 0;
    int q_index = 0;
    int a_index = 0;
    int mode = 1;
    for (c = getc(fp); c != EOF; c = getc(fp)) {
        if (c == '?'){
            quiz[i].question[q_index] = c;
            mode = 0;
            c = getc(fp);
        }
        else if (c == '\n'){
            mode = 1;
            i++;
        }
        if (mode == 1){
            quiz[i].question[q_index] = c;
            a_index = 0;
            q_index++;
        }
        else {
            quiz[i].answer[a_index] = c;
            a_index++;
            q_index = 0;
        }

    }

    fclose(fp);
    int j = 0;
    i = 0;

    //removes the space that would be at the start of every answer
    while (i < count){
        quiz[i].answer[j] = quiz[i].answer[j+1];
        if (quiz[i].answer[j] == NULL){
            j = 0;
            i++;
        } else{
            j++;
        }

    }
    i = 1;
    j = 0;

    //removes the \n at the start of all the questions after the the first one (the first one does have a \n)
    while (i < count){
        quiz[i].question[j] = quiz[i].question[j+1];
        if (quiz[i].question[j] == NULL){
            j = 0;
            i++;
        } else{
            j++;
        }

    }

    return count;
}

void render_quiz(int difficulty, int question_count){
    int correct = 0;
    int incorrect = 0;
    int asked_qs[question_count-1];
    int j;
    int index;
    int q_chooser;
    char hint[50];
    int difficulty_copy = difficulty;

    for (index = 0; index < question_count ; index++) {
        char answer[50];


        if (difficulty_copy == 6){
            // randomises difficulty
            while (1) {
                difficulty = rand() % 6;
                if (difficulty != 0){
                    break;
                } else{
                    continue;
                }
            }
        }

        while(1) {
            // ask random, non repeating questions
            q_chooser = rand() % question_count;
            int duplicate_counter = 0;
            for(j = 0; j < question_count; j++){
                if (asked_qs[j] == q_chooser) {
                    duplicate_counter++;
                }
            }
            if (duplicate_counter == 0){
                break;
            } else{
                continue;
            }

        }

        asked_qs[index] = q_chooser;
        printf("%s\n", quiz[q_chooser].question);

        int answerlen = strlen(quiz[q_chooser].answer);

        //difficulty 1
        if (difficulty == 1){
            printf("?\n");
        }

        //difficulty 2
        if (difficulty == 2){
            for(j = 0; j < answerlen; j++){
                hint[j] = '_';
            }
            printf("Hint: %s\n", hint);
            for(j = 0; j < answerlen; j++){
                hint[j] = ' ';
            }
        }

        //difficulty 3
        if (difficulty == 3){
            for(j = 0; j < answerlen; j++){
                if(j == 0 || j == answerlen - 1){
                    char temp = quiz[q_chooser].answer[j];
                    hint[j] = temp;
                }
                else{
                    hint[j] = '_';
                }
            }
            printf("Hint: %s\n", hint);

            for(j = 0; j < answerlen; j++){
                hint[j] = ' ';
            }
        }

        printf("Your answer: \n");
        scanf("%s", answer);

        for (j = 0; j < strlen(answer); j++)
        {
            answer[j]=tolower(answer[j]);
        }
        int tracker = 0;
        for (j = 0; j < answerlen; j++) {
            if (answer[j] != quiz[q_chooser].answer[j]){
                tracker++;
            }
        }
        if (tracker == 0){
            printf("Correct!\n");
            correct++;
        }

        if (tracker != 0){
            printf("Incorrect!\n");
            incorrect++;
        }
    }

    printf("You scored %d / %d\n", correct, question_count);


}


int main(int argc, char *argv[]) {
    if (argc > 3){
        printf("too many arguments");
        return 0;
    }

    char *path = argv[1];
    int difficulty = atoi(argv[2]);

    if (difficulty > 6 || difficulty == 0){
        printf("invalid difficulty\n");
        return 0;
    }

    int question_count = read_file(path);

    render_quiz(difficulty, question_count);

    return 0;
}
