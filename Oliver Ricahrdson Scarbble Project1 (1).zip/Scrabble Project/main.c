#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <ctype.h>

struct answer{
    char word[7];
}word_array[100];
/**
* Generates a number of random lower case letters.
* The letters will be stored in the given array.
*/
void generate_letters(int number, char *destination){
    char vowels[] = {'a', 'e', 'i', 'o', 'u'};
    int i;
    unsigned int rand_seed;
    printf("Number < 1000:\n");
    scanf("%d", &rand_seed); // initialise the PRNG
    getchar();
    srand(rand_seed);
// Half of the letters should be vowels
    for (i=0;i<number/2;i++, destination++) *destination = vowels[rand()%5];
    for (;i<number;i++, destination++) *destination = rand()%26+'a';

}

/**
* Tries to read the file into the array.
2
* Each line has one value.
*
* Returns the number of lines read or -1 in case of file open error.
*/
int read_array_from_file(const char* filepath, int *array, int array_length){
    FILE *file;
    int i;
    if ((file = fopen(filepath, "r")) == NULL) return -1;
    for (i=0;i<array_length;i++){
        if (fscanf(file, "%d", &array[i]) == EOF) break;
    }
    return i;
}



void check_for_duplicate(char letter_array[], int count[]){
    int i = 0, j;

    while (letter_array[i] != '\0') {
        if (letter_array[i] >= 'a' && letter_array[i] <= 'z' )
            count[letter_array[i]-'a']++;
        i++;
    }
    for (j = 0 ; j < 26 ; j++) {
        if(count[j] != 0){
            printf("%c --> %d\n", j + 'a', count[j]);
        }
    }
}

int user_input(int num_words){
    printf("Enter your word: ");
    scanf("%s", word_array[num_words].word);
    printf("your word is: %s\n", word_array[num_words].word);
    int i;
    for (i = 0; i < strlen(word_array[num_words].word); i++)
    {
        word_array[num_words].word[i]=tolower(word_array[num_words].word[i]);
    }
    num_words++;
    return num_words;
}

int check_word(int index, int count[], char letter_array[], int is_correct){
    index--;
    int word_length = strlen(word_array[index].word);
    int compare_letters = 0;
    if(word_length > 7){
        printf("your word is too long! You get 0 points!\n");
        return 0;
    }
    int i, j, k;
    for(i = 0; i < word_length; i++){
        for(j = 0; j < 7; j++){
            if(letter_array[j] == word_array[index].word[i]){
                compare_letters++;
            }
        }
        if(compare_letters == 0){
            printf("Your word has unavailable letters! 0 points!\n");
            is_correct = 0;
            return is_correct;
        }
        for(k = 0; k < 26; k++){
            if(word_array[index].word[i] == ('a' + k) && count[k] == 0) {
                printf("You are using a letter more times than it is available! 0 points!\n");
                is_correct = 0;
                return is_correct;
            }
            else  if(word_array[index].word[i] == ('a' + k) && count[k] != 0){
                count[k]--;
            }
        }
    }
    printf("Word is correct lets check how much its worth\n");
    is_correct = 1;
    return is_correct;
}

int calculate_score(int total_score, int index, int score_array[]){
    index --;
    int current_score = 0, i, j, length = strlen(word_array[index].word);
    for(i = 0; i < length; i++){
        for(j = 0; j < 26; j++){
            if(word_array[index].word[i] == 'a' + j){
                current_score += score_array[j];
            }
        }
    }
    total_score += current_score;
    printf("Your word scored %d points!\n Your total score is: %d\n", current_score, total_score);
    return total_score;
}

int main() {
    char letter_array[8];
    letter_array[7] = '\0';
    int score_array[26], num_words, total_score = 0, is_correct = 0;
    generate_letters(7, letter_array);
    read_array_from_file("C:\\Users\\Oliver\\CLionProjects\\Scrabble Project\\letter_values", score_array, 26);
    char input = 'y';
    while(input != 'n') {
        int count[26] = {0};
        printf("your letters are: %s\n", letter_array);
        check_for_duplicate(letter_array, count);
        num_words = user_input(num_words);
        is_correct = check_word(num_words, count, letter_array, is_correct);
        if(is_correct == 1){
           total_score = calculate_score(total_score, num_words, score_array);
        }
        printf("would you like to try again y/n?\n");
        scanf(" %c\n",&input);
        printf("you have chosen %c\n", input);
        if(input == 'n' || input == 'N'){
            printf("your score is: %d\n", total_score);
            break;
        }
        //the loop will continue or break depending on input but scanf from the function user_input will ask for your
        //word before anything else is printed again, it also does it if you break the loop
    }
    printf("-------Summary--------\nYou entered the following words:\n");
    int k;
    for(k = 0; k < num_words; k++){
        printf("%s\n", word_array[k].word);
    }
    printf("Your total score is %d\n", total_score);
    return 0;
}