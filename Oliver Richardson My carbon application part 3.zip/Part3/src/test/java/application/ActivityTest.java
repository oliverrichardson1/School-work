package application;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ActivityTest {
    Activity act = new Activity("1", "28/03/2020", "Cycling",10);
    String expected;
    int expected1;
    String actual;
    int actual1;

    @Test
    void getWeek() {
        String expected = "1";
        String actual = act.getWeek();
        assertEquals(expected, actual);
    }

    @Test
    void getActivity() {
        expected = "28/03/2020";
        actual = act.getDate();
        assertEquals(expected, actual);
    }

    @Test
    void getDate() {
        expected = "Cycling";
        actual = act.getActivity();
        assertEquals(expected, actual);
    }

    @Test
    void getPoints() {
        expected1 = 10;
        actual1 = act.getPoints();
        assertEquals(expected, actual);
    }

    @Test
    void setWeek() {
        expected = "2";
        act.setWeek(expected);
        actual = act.getWeek();
        assertEquals(expected, actual);
    }

    @Test
    void setDate() {
        expected = "29/03/2020";
        act.setDate(expected);
        actual = act.getDate();
        assertEquals(expected, actual);
    }

    @Test
    void setActivity() {
        expected = "eating a steak";
        act.setActivity(expected);
        actual = act.getActivity();
        assertEquals(expected, actual);
    }

    @Test
    void setPoints() {
        expected1 = -10;
        act.setPoints(expected1);
        actual1 = act.getPoints();
        assertEquals(expected1, actual1);
    }

    @Test
    void testToString() {
        expected = "Week: " + act.getWeek() + " Date: " + act.getDate() + " Activity: " + act.getActivity() + " Points: " + act.getPoints();
        actual = act.toString();
    }
}