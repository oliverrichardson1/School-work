package application;

import java.util.Comparator;

public class SortbyDate implements Comparator<Activity> {
    @Override
    public int compare(Activity a, Activity b) {
        return a.date.compareTo(b.date);
    }
}
