package application;

import java.util.Comparator;

public class SortbyActivity implements Comparator<Activity> {

    @Override
    public int compare(Activity a, Activity b) {
        return a.activity.compareTo(b.activity);
    }
}
