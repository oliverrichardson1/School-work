package application;

import javafx.scene.control.Tab;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * The intro tab is a basic tab with the title of the application and a nice background to go with it
 */

public class IntroTab extends Tab {
    public IntroTab() throws FileNotFoundException {
            GridPane gp = new GridPane();
            setText("Introduction");
            FileInputStream input = new FileInputStream("C:\\Users\\Oliver\\IdeaProjects\\Part3\\src\\main\\java\\application\\background.jpg");
            Image image = new Image(input);
            BackgroundImage backgroundImage = new BackgroundImage(image,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundRepeat.NO_REPEAT,
                    BackgroundPosition.DEFAULT,
                    BackgroundSize.DEFAULT);
            Background backGround = new Background(backgroundImage);
            Text title = new Text("My Carbon Impact");
            title.setFont(Font.font("verdana", FontWeight.BOLD, 20));
            title.setFill(Color.WHITE);
            title.setX(50);
            title.setY(50);
            gp.add(title, 0, 5);
            setContent(gp);

            gp.setBackground(backGround);
    }
}
