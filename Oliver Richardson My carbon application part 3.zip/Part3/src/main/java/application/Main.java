package application;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.util.ArrayList;

/**
 * This is the main to my carbon impact application
 * This application will allow you to record your daily activities and score them based on
 * how environmentally they are for -10 - +10
 * @author Oliver Richardson
 */

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        Activity act = new Activity();
        ArrayList<Activity> activityList = new ArrayList<>();
        try{
            BorderPane bp = new BorderPane();
            Group g = new Group();
            Scene scene = new Scene(g,500,360);
            TabPane tp = new TabPane();
            tp.getTabs().add(new IntroTab());
            tp.getTabs().add(new ActivityManageTab(activityList, act));
            tp.getTabs().add(new ResultsTab(activityList, act));
            bp.setCenter(tp);
            bp.prefHeightProperty().bind(scene.heightProperty());
            bp.prefWidthProperty().bind(scene.widthProperty());
            g.getChildren().add(bp);
            primaryStage.setScene(scene);primaryStage.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
