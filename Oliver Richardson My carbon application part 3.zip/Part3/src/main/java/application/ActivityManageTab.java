package application;

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.ArrayList;

/**
 * The ActivityManagementTab allows you to add, remove, summarise, calculate points, save and exit
 * This tab is where most of the functionality is called to from the controller class
 * @author Oliver Richardson
 */

public class ActivityManageTab extends Tab {
    private TextField weekTextField;
    private TextField activityTextField;
    private TextField pointsTextField;
    private DatePicker datePicker;

    public ActivityManageTab(ArrayList<Activity> ActivityList, Activity act){
        setText("Activity Management");
        Controller control = new Controller();

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.TOP_LEFT);
        grid.setHgap(10);
        grid.setVgap(3);

        HBox Weekbox = new HBox(10);
        Weekbox.setAlignment(Pos.TOP_LEFT);

        HBox Datebox = new HBox(10);
        Datebox.setAlignment(Pos.TOP_LEFT);

        HBox Activitybox = new HBox(10);
        Activitybox.setAlignment(Pos.TOP_LEFT);

        HBox Pointbox = new HBox(10);
        Pointbox.setAlignment(Pos.TOP_LEFT);

        Label week = new Label("Week___________");
        weekTextField = new TextField();
        act.setWeek(weekTextField.getText());

        Label date = new Label("Date____________");
        datePicker = new DatePicker();

        Label activity = new Label("Activity_________");
        activityTextField = new TextField();

        Label points = new Label("points -10--+10");
        pointsTextField = new TextField();

        Weekbox.getChildren().addAll(week, weekTextField);
        Datebox.getChildren().addAll(date, datePicker);
        Activitybox.getChildren().addAll(activity, activityTextField);
        Pointbox.getChildren().addAll(points, pointsTextField);

        grid.add(Weekbox,0,1);
        grid.add(Datebox,0,2);
        grid.add(Activitybox,0,3);
        grid.add(Pointbox,0,4);

        Button Add = new Button("Add");
        Button Remove = new Button("Remove");
        Button List = new Button("List");
        Button Summary = new Button("Summary");
        HBox hbBtn = new HBox(0);
        hbBtn.setAlignment(Pos.BOTTOM_LEFT);
        hbBtn.getChildren().add(Add);
        hbBtn.getChildren().add(Remove);
        hbBtn.getChildren().add(List);
        hbBtn.getChildren().add(Summary);
        grid.add(hbBtn, 0, 5);

        VBox VbTxtA = new VBox();
        VbTxtA.setAlignment(Pos.BOTTOM_LEFT);
        TextArea Activity_Display = new TextArea("Activities to be displayed");
        VbTxtA.getChildren().add(Activity_Display);
        grid.add(VbTxtA,0,6);

        HBox hbBtn2 = new HBox(20);
        Button load = new Button("Load");
        Button save = new Button("Save");
        Button exit = new Button("Exit");
        exit.setOnAction(e -> System.exit(0));
        hbBtn2.getChildren().addAll(load, save, exit);
        grid.add(hbBtn2, 0,7);

        Add.setOnAction(actionEvent -> control.add(ActivityList, weekTextField, datePicker, activityTextField, pointsTextField, act));

        List.setOnAction(actionEvent -> control.list(Activity_Display, ActivityList));

        Remove.setOnAction(actionEvent -> control.remove(ActivityList, activityTextField, Activity_Display));

        Summary.setOnAction(actionEvent -> control.summary(ActivityList, Activity_Display));

        save.setOnAction(actionEvent -> control.save(ActivityList));

        load.setOnAction(actionEvent -> control.load(ActivityList) );

        setContent(grid);
    }
}
