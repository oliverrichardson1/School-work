package application;

import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;

/**
 * This is the Controller class, it houses almost every method in the application and allows for most of the functionality
 * to happen
 * @author Oliver Ricardson
 */

public class Controller {
    /**
     * add allows the user to add their activities to be stored in an arraylist in the current instant
     */
    public void add(ArrayList<Activity> activityList, TextField weekText, DatePicker datePickerText, TextField activityText, TextField pointsText, Activity act){

        act.setWeek(weekText.getText());
        act.setDate(datePickerText.getValue().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        act.setActivity(activityText.getText());
        int points = Integer.parseInt(pointsText.getText());
        act.setPoints(points);
        activityList.add(act);
    }

    /**
     * Remove allows the user to remove an activity at a given index
     */
    public void remove(ArrayList<Activity> arrayList, TextField activity, TextArea activity_Display){

        try {
            int index = Integer.parseInt(activity.getText());

            if (arrayList.size() == 0) {
                activity_Display.setText("\n are no activities to be removed!");
            }
            else if (activity.getText() == null || index > (arrayList.size() - 1)) {
                activity_Display.setText("\nEnter a valid index!, if you need to see a list of index's click the List button!");
            }
            else {
                arrayList.remove(index);
                activity_Display.setText("\nActivity removed!");
            }
            }
        catch (NumberFormatException e){
            e.printStackTrace();
        }
    }

    /**
     * Lists all of the activity objects and formats the so they are readable using the toString method of the activity class
     */
    public void list(TextArea Activity_Display, ArrayList<Activity> activityList){

        StringBuilder allActivities = new StringBuilder(Activity_Display.getText());
        if(activityList.size() == 0){
            allActivities.append("\nThere are no activities to display!");
            Activity_Display.setText(allActivities.toString());
        }
        else {
            for (int i = 0; i < activityList.size(); i++) {
                String str = activityList.get(i).toString();
                allActivities.append("\n").append(i).append(str);
            }

            Activity_Display.setText(allActivities + "\n If you want to remove an activity, type the index of the " +
                    "activity into the activity text box!");
        }
    }

    /**
     * Calculates and Displays the current total score of all activities
     */
    public void summary(ArrayList<Activity> activityList, TextArea display_area){

        int totalPoints = 0;
        for (Activity activity : activityList) {
            totalPoints += activity.getPoints();
        }
        display_area.setText(display_area.getText() + "\n Total Points: " + totalPoints);
    }

    /**
     * All activity objects stored in the activityArrayList are serialized and stored in a text file
     */
    public void save(ArrayList<Activity> activityList){
        String filename = "C:\\Users\\Oliver\\eclipse-workspace\\Carbon Emissions Lab2\\src\\application\\activities.txt";
        try{
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
            for (Activity activity : activityList) {
                out.writeObject(activity);
                System.out.print("object serialized");
            }
            out.close();
            file.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Deserializes objects stored in the text file
     */
    public void load(ArrayList<Activity> activityList){
        String filename = "C:\\Users\\Oliver\\eclipse-workspace\\Carbon Emissions Lab2\\src\\application\\activities.txt";
        try
        {
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);
            while (in.readObject() != null){
                activityList.add((Activity) in.readObject());
            }

            in.close();
            file.close();
        }

        catch(IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * uses a comparator class to sort activity objects by date
     */
    public void SortbyDate(ArrayList<Activity> activityList, TextArea ta){
        Collections.sort(activityList, new SortbyDate());

        for (Activity value : activityList) {
            ta.setText(ta.getText() + "\n" + value);
        }
        int totalPoints = 0;
        for (Activity value : activityList) {
            ta.setText(ta.getText() + "\n" + value.toString());
        }
        ta.setText(ta.getText() + "\n Total Points: " + totalPoints);
    }


    /**
     *uses comparator class to sort objects in alphabetical order
     */
    public void SortbyActivity(ArrayList<Activity> activityList, TextArea ta){
        Collections.sort(activityList, new SortbyActivity());

        for (Activity value : activityList) {
            ta.setText(ta.getText() + "\n" + value.toString());
        }
        int totalPoints = 0;
        for (Activity activity : activityList) {
            totalPoints += activity.getPoints();
        }
        ta.setText(ta.getText() + "\n Total Points: " + totalPoints);
    }

}
