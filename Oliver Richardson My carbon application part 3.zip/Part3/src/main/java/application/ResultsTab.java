package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import java.util.ArrayList;

/**
 * The results tab allows you to organise all your recorded activities by date or by alphabetical order
 * @author Oliver Richardson
 */

public class ResultsTab extends Tab {
    public ResultsTab(ArrayList<Activity> activityList, Activity act){
        setText("Results");
        GridPane grid = new GridPane();
        grid.setVgap(10);
        grid.setHgap(10);
        Controller control = new Controller();


        HBox hb1 = new HBox();
        HBox hb2 = new HBox();
        HBox hb3 = new HBox();
        HBox hb4 = new HBox();

        Label selectDate = new Label("Order Activities by : ");
        Label selectActivity = new Label("Order Activities by : ");
        Button Date = new Button("Date");
        Button Activities = new Button("Activities");
        Button Memory = new Button("memory usage");
        TextArea ta = new TextArea();

        hb1.getChildren().addAll(selectDate, Date);
        hb2.getChildren().addAll(selectActivity, Activities);
        hb3.getChildren().add(ta);
        hb4.getChildren().add(Memory);

        grid.add(hb1, 0, 0);
        grid.add(hb2,0,1);
        grid.add(hb3,0,2);
        grid.add(hb4,0,3);

        Date.setOnAction(actionEvent -> control.SortbyDate(activityList, ta));
        Activities.setOnAction(actionEvent -> control.SortbyActivity(activityList, ta));
        Memory.setOnAction(actionEvent -> {
            /**
             * This button is used to show poor memory management, after pressing this button, memory usage goes up by
             * several gigabytes
             */
            while (true) {
                Activity act1 = new Activity("1", "28/03/2020", "Cycling", 10);
                activityList.add(act1);
            }
        });

        setContent(grid);
    }
}
