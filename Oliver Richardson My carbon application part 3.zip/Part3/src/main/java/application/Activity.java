package application;

import java.io.Serializable;

/**
 * The activity class is used for creating the activity object, which stores the following information about an activty:
 * week of activity, date, type of activity, how many points the activity scores
 * @author Oliver Richardson
 */
public class Activity implements Serializable {  private static final long serialVersionUID = 1L;
    private String week;
    public String date;
    public String activity;
    private int points;

    public Activity() {//constructor
    }

    public Activity(String week, String date, String activity, int points){
        this.week = week;
        this.date = date;
        this.activity = activity;
        this.points = points;


    }

    public String getWeek() {
        return week;
    }

    public String getActivity() {
        return activity;
    }

    public String getDate() {
        return date;
    }

    public int getPoints() {
        return points;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public String toString(){
        return "Week: " + this.week + " Date: " + this.date + " Activity: " + this.activity + " Points: " + this.points;
    }
}
